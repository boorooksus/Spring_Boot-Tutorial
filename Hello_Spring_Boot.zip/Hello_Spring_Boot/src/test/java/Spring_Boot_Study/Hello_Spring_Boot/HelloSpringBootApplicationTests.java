package Spring_Boot_Study.Hello_Spring_Boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
